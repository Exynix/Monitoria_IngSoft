package co.edu.javeriana.ingsoft.quemadiaria.solid.b.usecases;

public class CifrarTexto {
}
