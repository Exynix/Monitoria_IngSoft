package co.edu.javeriana.ingsoft.quemadiaria.solid.e.interfaces.main;

public class Menu {

}
